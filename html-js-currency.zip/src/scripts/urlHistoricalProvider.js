export class UrlHistoricalProvider {
//asd
    static provide(fun, from, to, inter) {
        return  'https://www.alphavantage.co/query?function=' + fun + '&from_symbol=' + from + '&to_symbol=' + to + inter + '&apikey=J3IPR8A064WO3OI9';
    }
}